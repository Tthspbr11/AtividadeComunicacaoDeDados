# Análise de Programação de Socket UDP e TCP

**Matrícula:** 10399 — **Porta usada na Questão 2 e na Questão 3:** 10399

## Questão 1 — Execução dos programas TCP e UDP

Programas analisados: `TCP/Servidor.py` (porta 24000), `TCP/Cliente.py`, `UDP/Servidor.py` (porta 5005) e `UDP/Cliente.py`.
Testes feitos com cliente e servidor no mesmo computador (IP 127.0.0.1); com os arquivos originais, o comportamento é o mesmo usando o IP 192.168.0.3 em máquinas da mesma rede.

### a) Cliente TCP executado antes do servidor TCP

**O que acontece:** o cliente é encerrado com erro na linha `cliente.connect((TCP_IP, TCP_PORTA))`:

```
ConnectionRefusedError: [Errno 111] Connection refused
```
(no Windows: `ConnectionRefusedError: [WinError 10061]`)

**Por quê:** o TCP é um protocolo orientado a conexão. O `connect()` inicia o handshake de 3 vias (SYN, SYN+ACK, ACK). Como o servidor ainda não executou `bind()` e `listen()`, não há processo escutando na porta 24000, e o sistema operacional do destino responde ao SYN com um segmento RST, recusando a conexão. O erro, portanto, é detectado imediatamente pelo cliente.

### b) Cliente UDP executado antes do servidor UDP

**O que acontece:** o cliente imprime as três linhas (IP, porta e mensagem), termina normalmente e **não gera nenhum erro**.

**Comparação com o TCP:**

| | TCP | UDP |
|---|---|---|
| Tipo de socket | `SOCK_STREAM` | `SOCK_DGRAM` |
| Conexão prévia | Sim (handshake de 3 vias) | Não |
| Cliente antes do servidor | Erro: conexão recusada | Sem erro; a mensagem se perde |
| Confirmação de entrega | Sim (ACK, retransmissão) | Não |
| Quem detecta a ausência do servidor | O `connect()`, na hora | Ninguém |

**Justificativa:** o resultado **não** foi similar. No UDP não existe conexão: o `sendto()` apenas entrega o datagrama à rede, sem verificar se há alguém recebendo, e não há retransmissão. A mensagem "Hello, World!" foi enviada, mas descartada no destino porque nenhum processo estava ligado à porta. O UDP é mais leve e rápido, porém não garante entrega; o TCP garante entrega e ordem ao custo da conexão.

### c) Porta do cliente diferente da porta do servidor

- **TCP** (servidor na 24000, cliente na 24001): o cliente falha com o mesmo `ConnectionRefusedError`, pois não há ninguém escutando na porta 24001. A conexão nunca é estabelecida e o servidor continua aguardando no `accept()`.
- **UDP** (servidor na 5005, cliente na 5006): o cliente termina sem erro, mas o servidor **não recebe nada** (testado: o log do servidor ficou vazio). O datagrama é enviado a uma porta onde não há processo e é descartado.

Conclusão: a porta identifica o processo/serviço no destino. Com porta errada o TCP avisa o erro; o UDP falha em silêncio.

### Observações sobre os códigos (encontradas na análise)

1. `TCP/Servidor.py`: depois que o cliente se desconecta, `recv()` retorna `b''` indefinidamente e o `while 1` não tem `break`, mantendo o servidor em loop ocupando CPU (medido: cerca de 43% de CPU).
2. `TCP/Servidor.py`: imprime "porta 5005", mas escuta na porta 24000.
3. `listen(1)` e um único `accept()`: o servidor atende apenas um cliente. O desafio da Questão 3 resolve isso com threads.
4. `TCP/Cliente.py`: usa `recvfrom` (próprio de UDP) em socket TCP; o correto é `recv`.
5. A variável `TAMANHO_BUFFER` é declarada no cliente TCP e não é usada.

## Questão 2 — Chat TCP com QUIT

Pasta `Questao2_Chat/`: `servidor_chat.py` e `cliente_chat.py`, porta **10399**.
Execução: primeiro o servidor, depois o cliente. O cliente fala primeiro e as mensagens se alternam até um dos lados enviar `QUIT`.

## Questão 3 — Desafio: sala de chat multiusuário com threads e envio de arquivos

Pasta `Questao3_ChatSala/` (porta **10399**). Execução: `python servidor.py` e, em outros terminais ou computadores, `python cliente.py` (ajuste `IP_SERVIDOR` no `cliente.py` se estiver em outra máquina).

### Checklist das condições do professor

| Condição | Como o projeto atende |
|---|---|
| Fazer um chat e oferecer menu de transferência de arquivos | Menu com mensagem pública/privada, envio de arquivo para todos ou para um usuário, listar usuários e sair |
| O usuário escolhe qual arquivo enviar | O programa lista os arquivos da pasta ou aceita um caminho digitado; nenhum arquivo é fixo no código |
| Transmitir o arquivo via socket | Cabeçalho JSON com nome e tamanho, seguido dos bytes do arquivo; recebido em `recebidos/` |
| Tratar várias conexões com threads | Servidor cria uma thread por cliente; o cliente tem thread própria para receber |
| Não é simples transferência de arquivos | É uma sala de chat com várias conexões, mensagens privadas e arquivos |
| Não é jogo da velha nem quiz | Atende |
| Vídeo mostrando funcionamento e explicando o código | **A gravar (ver roteiro abaixo)** |

### Roteiro sugerido para o vídeo (5 a 8 minutos)

1. **Demonstração (2 min):** abrir o servidor e 3 clientes. Mostrar mensagem para todos, mensagem privada, listar usuários e envio de um arquivo (para todos e para um só), abrindo a pasta `recebidos/` para provar que chegou.
2. **`protocolo.py`:** explicar por que o TCP é fluxo de bytes e por isso cada mensagem leva 4 bytes de tamanho antes do JSON; `receber_exato` existe porque `recv` pode devolver menos bytes do que o pedido; a `trava` evita que duas threads misturem bytes no mesmo socket.
3. **`servidor.py`:** `accept()` em laço criando uma `Thread` por cliente; dicionário `clientes` protegido por `trava_clientes`; como as mensagens são encaminhadas e como o arquivo é lido e repassado; tratamento de desconexão no `finally`.
4. **`cliente.py`:** thread de recepção separada do menu (por isso mensagens chegam enquanto o usuário digita); `escolher_arquivo()` com `os.listdir`; leitura do arquivo em modo binário `"rb"` e gravação em `"wb"`; uso de `os.path.basename` para impedir caminhos maliciosos no nome do arquivo.
5. **Encerramento:** comparar com o servidor TCP da Questão 1 (um cliente só) e mostrar que agora vários clientes são atendidos ao mesmo tempo.
